<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <title>Zadania na lipiec</title>
        <link rel="stylesheet" href="styl6.css">
    </head>
    <body>
        <header>
            <section class="baner1">
                <img src="logo1.png" alt="lipiec" height="140px">
            </section>

            <section class="baner2">
                <h1>TERMINARZ</h1>
                <p>Najbliższe Zadania</p>
                <?php
                $db = mysqli_connect('localhost', 'root', '', 'terminarz');
                $q = 'SELECT DISTINCT wpis FROM zadania WHERE dataZadaia <= "2020-07-07" AND dataZadania >= "2020-07-01" AND wpis <> "";';
                $wynikzapytania = mysqli_query($db, $q);
                $wpisy = "";
                while($row = mysqli_fetch_array($wynikzapytania))
                {
                    $wpisy .= $row("wpis") ."; ";
                }
                echo $wpisy;
                ?>
            </section>
        </header>
        <main>
            <?php
            $q = 'SELECT dataZadania, wpis FROM zadania WHERE miesiac="lipiec":';
            $wynikzapytania = mysqli_query($baza, $q);
            while($row = mysqli_fetch_array($wynikzapytania))
            {
                $wpisy .= $row["wpis"] ."; ";
                echo '<section class="kalendarz">
                <h6>' .$row["dataZadania"]. '</h6>
                <p>' .$row["wpis"]. '</p>
                </section>';

            }

            ?>
        </main>
        <footer>
            <a href="sierpien.html">Terminarz na Siepień</a>
            <p>Stronę Wykonał: 00000000000</p>
        </footer>
    </body>
</html>